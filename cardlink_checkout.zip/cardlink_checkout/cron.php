<?php

$_GET['fc'] = 'module';
$_GET['module'] = 'cardlink_checkout';
$_GET['controller'] = 'cron';

require_once dirname(__FILE__) . '/../../index.php';
